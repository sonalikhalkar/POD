package com.ril.SC_SB_SCM_POD_SEARCHAPI.exceptionhandler;

public class CustomException extends Exception
{

	private static final long serialVersionUID = 1L;
	
    private final String msg;

	public CustomException(String msg) 
	{
		this.msg = msg;
	}

	public String getMsg() {
		return msg;
	}

}
