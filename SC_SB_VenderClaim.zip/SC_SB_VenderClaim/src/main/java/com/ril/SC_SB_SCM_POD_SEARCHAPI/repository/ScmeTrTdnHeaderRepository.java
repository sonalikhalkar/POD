package com.ril.SC_SB_SCM_POD_SEARCHAPI.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ScmeTrTdnInvHeader;

public interface ScmeTrTdnHeaderRepository extends JpaRepository<ScmeTrTdnInvHeader, String> 
{
	@Query(value="SELECT distinct p1.refdocno, count(p2.cn_no) as CN_count, p1.veh_no, hd.source_location, hd.destination_location, hd.shipment_start_date, p1.vendor_code, p1.cust_id,p1.shipmenttype,p1.tpp from SCME_TR_TDN_INV_HEADER p1 left join\r\n" + 
			"SCME_TR_TDN_INV_DETAILS p2 on p1.tdn = p2.tdn and p1.fyear = p2.fyear left join SCME_TR_TO_HEADER_DATA hd on p1.refdocno = hd.shipment_no where p1.tdn_status = :tdn_status\r\n" + 
			"and p1.shippingtype in (:mode) and p1.cust_id in (:cust_id) and p1.consignment_category in (:service_cat) and p1.vendor_code = :vendor_code and p2.cndate between :start_date and :end_date and p1.trbillno is null and p1.trbilldate is null and p1.trbillfyear is null group by "
			+ "p1.refdocno, p1.veh_no, hd.source_location, hd.destination_location, hd.shipment_start_date, p1.vendor_code, p1.cust_id,p1.shipmenttype,p1.tpp",nativeQuery = true)
	public List<Object> getShipmentList(String vendor_code,String start_date,String end_date,String mode,String service_cat,String cust_id,String tdn_status);
}
