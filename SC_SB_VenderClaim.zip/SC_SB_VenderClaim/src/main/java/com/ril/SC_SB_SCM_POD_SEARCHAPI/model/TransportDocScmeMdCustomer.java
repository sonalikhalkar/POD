package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class TransportDocScmeMdCustomer implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	@NotNull
	private int CUSTOMER_ID;
	@NotNull
	private String BUSINESS_AREA;
	@NotNull
	private String SUB_BUSINESS_AREA;
	
	public int getCUSTOMER_ID() {
		return CUSTOMER_ID;
	}
	public void setCUSTOMER_ID(int cUSTOMER_ID) {
		CUSTOMER_ID = cUSTOMER_ID;
	}
	public String getBUSINESS_AREA() {
		return BUSINESS_AREA;
	}
	public void setBUSINESS_AREA(String bUSINESS_AREA) {
		BUSINESS_AREA = bUSINESS_AREA;
	}
	public String getSUB_BUSINESS_AREA() {
		return SUB_BUSINESS_AREA;
	}
	public void setSUB_BUSINESS_AREA(String sUB_BUSINESS_AREA) {
		SUB_BUSINESS_AREA = sUB_BUSINESS_AREA;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
