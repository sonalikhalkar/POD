package com.ril.SC_SB_SCM_POD_SEARCHAPI.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.ril.SC_SB_SCM_POD_SEARCHAPI.util.ResponseFormat;


@Component
@ControllerAdvice
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler
{

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) throws Exception
	{	
		ResponseFormat resFormat1 = new ResponseFormat();
		resFormat1.setMessage(ex.getMessage());
		//resFormat1.setTimestamp(LocalDateTime.now());
		
		return new ResponseEntity<>(resFormat1, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<Object> CustomException(CustomException ex, WebRequest request) 
	{
		ResponseFormat resFormat2 = new ResponseFormat();
		resFormat2.setMessage(ex.getMsg());
		//resFormat2.setTimestamp(LocalDateTime.now());
		
		return new ResponseEntity<>(resFormat2, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		ResponseFormat resFormat3 = new ResponseFormat();
		resFormat3.setMessage(ex.getMessage());
		//resFormat3.setTimestamp(LocalDateTime.now());
		return new ResponseEntity<>(resFormat3, HttpStatus.BAD_REQUEST);
	}

}
