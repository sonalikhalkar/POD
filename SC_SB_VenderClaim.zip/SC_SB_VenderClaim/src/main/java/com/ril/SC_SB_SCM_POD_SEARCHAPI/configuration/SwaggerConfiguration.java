package com.ril.SC_SB_SCM_POD_SEARCHAPI.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfiguration
{

	private static final String TITLESWAGG = "POD SEARCH API";
	private static final String DESCRIPTIONSWAGG = "POD SEARCH API";
	private static final String LICENSESWAGG = "POD SEARCH API License";
	private static final String VERSIONSWAGG = "1.0";
	
	@Bean
	public ApiInfo apiInfo()
	{
		return new ApiInfoBuilder().title(TITLESWAGG).description(DESCRIPTIONSWAGG).license(LICENSESWAGG)
		        .version(VERSIONSWAGG).build();
	}
	
	@Bean
	public Docket postApi()
	{
		return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo()).pathMapping("/").select()
		        .apis(RequestHandlerSelectors.basePackage("com.ril.SC_SB_SCM_POD_SEARCHAPI"))
		      
		        .build();
	}
	
}
