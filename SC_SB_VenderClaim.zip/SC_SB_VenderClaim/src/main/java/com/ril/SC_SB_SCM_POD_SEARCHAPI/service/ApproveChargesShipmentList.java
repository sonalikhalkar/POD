package com.ril.SC_SB_SCM_POD_SEARCHAPI.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ScmeTrTdnInvDetails;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ScmeTrTdnInvHeader;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ShipementList;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.repository.ScmeTrTdnHeaderRepository;

@Service
public class ApproveChargesShipmentList 
{	
	
	@Autowired
	ScmeTrTdnHeaderRepository scmeTrTdnHeaderRepository;

	public List<ShipementList> getShipmentList(String vendor_code, Date start_date, Date end_date, String mode, String service_cat, String cust_id, String tdn_status)
	{
		DateFormat formatter = null; 
		String sconvertedDate = null; 
		String econvertedDate = null; 
		
		formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		sconvertedDate = formatter.format(start_date);
		
		econvertedDate = formatter.format(end_date);
		
		List<ShipementList> dtlListObj = new ArrayList<>();
		List<Object> scmeTrTdnInvHeaderList = new ArrayList<>();
		scmeTrTdnInvHeaderList=scmeTrTdnHeaderRepository.getShipmentList(vendor_code, sconvertedDate, econvertedDate, mode, service_cat, cust_id, tdn_status);
		

		for(int i = 0; i < scmeTrTdnInvHeaderList.size(); i++ )
		{
			ShipementList ship= new ShipementList();
			
			ship.setCN_count(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getTransportDocHeaderIdentity().getTdn());
			ship.setCust_id(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getCust_id());
			ship.setDestination_location(((ScmeTrTdnInvDetails) scmeTrTdnInvHeaderList.get(i)).getSourcetzone());
			ship.setEnd_date(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getTdn_enddate());
			ship.setRefdocno(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getRefdocno());
			ship.setShipment_start_date(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getTdn_startdate());
			ship.setShipmenttype(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getShipmenttype());
			ship.setSource_location(((ScmeTrTdnInvDetails) scmeTrTdnInvHeaderList.get(i)).getDesttzone());
			ship.setStart_date(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getTdn_startdate());
			ship.setTpp(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getTpp());
			ship.setVeh_no(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getVeh_no());
			ship.setVendor_code(((ScmeTrTdnInvHeader) scmeTrTdnInvHeaderList.get(i)).getVendor_code());
			
			dtlListObj.add(ship);
		}
		return dtlListObj;
	}
	
	
}
