package com.ril.SC_SB_SCM_POD_SEARCHAPI.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ScmeTrToHeaderData;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.SupplyChainMgmtSearchList;

public interface ScmeTrToHeaderDataRepository extends JpaRepository<ScmeTrToHeaderData, String>
{
	@Query(value="select p3.customer_name, p3.customer_id, p1.source_location, p1.destination_location, p1.shipment_date, p2.name,\r\n" + 
			" p1.vendor_code,p1.vehicle_number, p1.vehicle_type, p1.vehicle_capacity, p1.route_distance \r\n" + 
			" from SCME_TR_TO_HEADER_DATA p1, m2_vendor p2, SCME_MD_CUSTOMER p3 \r\n" + 
			" where p1.vendor_code = p2.vendor_code and p3.customer_id = p1.scm_customer_id \r\n" + 
			" and p1.transport_order_no in (:transport_order_no) and p3.customer_name in (:customer_name) and \r\n" + 
			" p2.name in (:name) and p1.vehicle_number in (:vehicle_number) and p1.source_location in (:source_location)\r\n" + 
			" and p1.destination_location in (:destination_location) and p1.shipment_date in (:shipment_date)",nativeQuery = true)
	
	public List<Object[]> getSearchList(int transport_order_no, String customer_name, String name, String vehicle_number, String source_location, String destination_location, String shipment_date);
}

