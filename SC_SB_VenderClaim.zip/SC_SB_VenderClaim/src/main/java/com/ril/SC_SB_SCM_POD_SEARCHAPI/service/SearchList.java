package com.ril.SC_SB_SCM_POD_SEARCHAPI.service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.M2vendor;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ScmeMdCustomer;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ScmeTrTdnInvHeader;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ScmeTrToHeaderData;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ShipementList;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.SupplyChainMgmtSearchList;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.repository.ScmeTrToHeaderDataRepository;

@Service
public class SearchList 
{
	@Autowired
	ScmeTrToHeaderDataRepository scmeTrToHeaderDataRepository;

	public List<SupplyChainMgmtSearchList> getSearchList(int transport_order_no, String cust_name, String vendor_name, String vehicle_number, String source_location, String destination_location, Date shipment_date)
	{
		DateFormat formatter = null; 
		String shipementconvertedDate = null; 
		String econvertedDate = null; 
		
		formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		shipementconvertedDate = formatter.format(shipment_date);
		
		List<SupplyChainMgmtSearchList> dtlListObj = new ArrayList<>();
		List<Object[]> scmeTrToHeaderList = new ArrayList<>();
		scmeTrToHeaderList=scmeTrToHeaderDataRepository.getSearchList(transport_order_no, cust_name, vendor_name, vehicle_number, source_location, destination_location, shipementconvertedDate);
		

		for(int i = 0; i < scmeTrToHeaderList.size(); i++ )
		{
			SupplyChainMgmtSearchList supplyChain = new SupplyChainMgmtSearchList();

			supplyChain.setCustomer_id((String)(scmeTrToHeaderList.get(i)[1]));
			supplyChain.setCustomer_name((String)(scmeTrToHeaderList.get(i)[0]));
			supplyChain.setDestination_location((String)( scmeTrToHeaderList.get(i)[3]));
			supplyChain.setRoute_distance((String)( scmeTrToHeaderList.get(i)[10]));
			supplyChain.setShipment_date((Date)( scmeTrToHeaderList.get(i)[4]));
			supplyChain.setSource_location((String)( scmeTrToHeaderList.get(i)[2]));
			supplyChain.setVehicle_capacity(((BigDecimal)scmeTrToHeaderList.get(i)[9]).doubleValue());
			supplyChain.setVehicle_number((String)( scmeTrToHeaderList.get(i)[7]));
			supplyChain.setVehicle_type((String)(scmeTrToHeaderList.get(i)[8]));
			supplyChain.setVendor_code((String)( scmeTrToHeaderList.get(i)[6]));
			supplyChain.setVendor_name((String)( scmeTrToHeaderList.get(i)[5]));
			dtlListObj.add(supplyChain);
		}
		
		return dtlListObj;

	}
}

