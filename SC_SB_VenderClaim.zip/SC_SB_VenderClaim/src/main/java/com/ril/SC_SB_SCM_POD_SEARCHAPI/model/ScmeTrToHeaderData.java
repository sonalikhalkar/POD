package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.util.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="SCME_TR_TO_HEADER_DATA")
public class ScmeTrToHeaderData
{
	@EmbeddedId
	TransportDocTrToHeaderData transportDocTrToHeaderData;

	private Date shipment_date;
	private String shipment_status;
	private String vehicle_number;
	private String source_location;
	private String source_statecode; 
	private String source_zone;
	private String source_postalcode;
	private String destination_location; 
	private String destination_statecode;
	private String destination_zone;
	private String destination_postalcode;
	private String trans_service_category;
	private String transport_mode;
	private String route_id;
	private String vehicle_type;
	private double vehicle_capacity;
	private String vehicle_capacity_uom;
	private String container_id;
	private String trip_number;
	private String vendor_code;
	private Date planned_vehicle_placement_date;
	private Date planned_vehicle_placement_time;
	private Date actual_date_of_checkin;
	private Date actual_time_of_checkin;
	private Date shipment_start_date;
	private Date shipment_start_time;
	private String special_processing_indicator ; 
	private String transhipment_vehicle_no ;
	private String transhipment_location ;
	private String reason_for_vendor_change;
	private String reason_description_for_vendor_change;
	private int manifest_number;
	private String route_distance;
	private String route_distance_uom; 
	private String server;
	private String shipping_type_descr;
	private String vehicle_type_descr;
	private String driver_name;
	private String licence_no;
	private Date expiry_date; 
	private String licence_issuing_state;
	private String grn_applicable;
	private String attendance_applicable;
	private int transport_order_no; 
	private Date transport_order_date;
	private String return_order;
	private int onward_reference;
	private String business_id; 
	private String subusiness_id;
	private String product_category;
	private String gst_plant;
	private String ctd_indicator;
	private String consignment_category;
	private String movt_dir;
	private float cust_apprv_ftl_qty ;
	private String createdbyid;
	private Date createdon;
	private String createdbyname;
	
	
	public TransportDocTrToHeaderData getTransportDocTrToHeaderData() {
		return transportDocTrToHeaderData;
	}
	public void setTransportDocTrToHeaderData(TransportDocTrToHeaderData transportDocTrToHeaderData) {
		this.transportDocTrToHeaderData = transportDocTrToHeaderData;
	}
	public Date getShipment_date() {
		return shipment_date;
	}
	public void setShipment_date(Date shipment_date) {
		this.shipment_date = shipment_date;
	}
	public String getShipment_status() {
		return shipment_status;
	}
	public void setShipment_status(String shipment_status) {
		this.shipment_status = shipment_status;
	}
	public String getVehicle_number() {
		return vehicle_number;
	}
	public void setVehicle_number(String vehicle_number) {
		this.vehicle_number = vehicle_number;
	}
	public String getSource_location() {
		return source_location;
	}
	public void setSource_location(String source_location) {
		this.source_location = source_location;
	}
	public String getSource_statecode() {
		return source_statecode;
	}
	public void setSource_statecode(String source_statecode) {
		this.source_statecode = source_statecode;
	}
	public String getSource_zone() {
		return source_zone;
	}
	public void setSource_zone(String source_zone) {
		this.source_zone = source_zone;
	}
	public String getSource_postalcode() {
		return source_postalcode;
	}
	public void setSource_postalcode(String source_postalcode) {
		this.source_postalcode = source_postalcode;
	}
	public String getDestination_location() {
		return destination_location;
	}
	public void setDestination_location(String destination_location) {
		this.destination_location = destination_location;
	}
	public String getDestination_statecode() {
		return destination_statecode;
	}
	public void setDestination_statecode(String destination_statecode) {
		this.destination_statecode = destination_statecode;
	}
	public String getDestination_zone() {
		return destination_zone;
	}
	public void setDestination_zone(String destination_zone) {
		this.destination_zone = destination_zone;
	}
	public String getDestination_postalcode() {
		return destination_postalcode;
	}
	public void setDestination_postalcode(String destination_postalcode) {
		this.destination_postalcode = destination_postalcode;
	}
	public String getTrans_service_category() {
		return trans_service_category;
	}
	public void setTrans_service_category(String trans_service_category) {
		this.trans_service_category = trans_service_category;
	}
	public String getTransport_mode() {
		return transport_mode;
	}
	public void setTransport_mode(String transport_mode) {
		this.transport_mode = transport_mode;
	}
	public String getRoute_id() {
		return route_id;
	}
	public void setRoute_id(String route_id) {
		this.route_id = route_id;
	}
	public String getVehicle_type() {
		return vehicle_type;
	}
	public void setVehicle_type(String vehicle_type) {
		this.vehicle_type = vehicle_type;
	}
	
	public double getVehicle_capacity() {
		return vehicle_capacity;
	}
	public void setVehicle_capacity(double vehicle_capacity) {
		this.vehicle_capacity = vehicle_capacity;
	}
	public String getVehicle_capacity_uom() {
		return vehicle_capacity_uom;
	}
	public void setVehicle_capacity_uom(String vehicle_capacity_uom) {
		this.vehicle_capacity_uom = vehicle_capacity_uom;
	}
	public String getContainer_id() {
		return container_id;
	}
	public void setContainer_id(String container_id) {
		this.container_id = container_id;
	}
	public String getTrip_number() {
		return trip_number;
	}
	public void setTrip_number(String trip_number) {
		this.trip_number = trip_number;
	}
	public String getVendor_code() {
		return vendor_code;
	}
	public void setVendor_code(String vendor_code) {
		this.vendor_code = vendor_code;
	}
	public Date getPlanned_vehicle_placement_date() {
		return planned_vehicle_placement_date;
	}
	public void setPlanned_vehicle_placement_date(Date planned_vehicle_placement_date) {
		this.planned_vehicle_placement_date = planned_vehicle_placement_date;
	}
	public Date getPlanned_vehicle_placement_time() {
		return planned_vehicle_placement_time;
	}
	public void setPlanned_vehicle_placement_time(Date planned_vehicle_placement_time) {
		this.planned_vehicle_placement_time = planned_vehicle_placement_time;
	}
	public Date getActual_date_of_checkin() {
		return actual_date_of_checkin;
	}
	public void setActual_date_of_checkin(Date actual_date_of_checkin) {
		this.actual_date_of_checkin = actual_date_of_checkin;
	}
	public Date getActual_time_of_checkin() {
		return actual_time_of_checkin;
	}
	public void setActual_time_of_checkin(Date actual_time_of_checkin) {
		this.actual_time_of_checkin = actual_time_of_checkin;
	}
	public Date getShipment_start_date() {
		return shipment_start_date;
	}
	public void setShipment_start_date(Date shipment_start_date) {
		this.shipment_start_date = shipment_start_date;
	}
	public Date getShipment_start_time() {
		return shipment_start_time;
	}
	public void setShipment_start_time(Date shipment_start_time) {
		this.shipment_start_time = shipment_start_time;
	}
	public String getSpecial_processing_indicator() {
		return special_processing_indicator;
	}
	public void setSpecial_processing_indicator(String special_processing_indicator) {
		this.special_processing_indicator = special_processing_indicator;
	}
	public String getTranshipment_vehicle_no() {
		return transhipment_vehicle_no;
	}
	public void setTranshipment_vehicle_no(String transhipment_vehicle_no) {
		this.transhipment_vehicle_no = transhipment_vehicle_no;
	}
	public String getTranshipment_location() {
		return transhipment_location;
	}
	public void setTranshipment_location(String transhipment_location) {
		this.transhipment_location = transhipment_location;
	}
	public String getReason_for_vendor_change() {
		return reason_for_vendor_change;
	}
	public void setReason_for_vendor_change(String reason_for_vendor_change) {
		this.reason_for_vendor_change = reason_for_vendor_change;
	}
	public String getReason_description_for_vendor_change() {
		return reason_description_for_vendor_change;
	}
	public void setReason_description_for_vendor_change(String reason_description_for_vendor_change) {
		this.reason_description_for_vendor_change = reason_description_for_vendor_change;
	}
	public int getManifest_number() {
		return manifest_number;
	}
	public void setManifest_number(int manifest_number) {
		this.manifest_number = manifest_number;
	}
	public String getRoute_distance() {
		return route_distance;
	}
	public void setRoute_distance(String route_distance) {
		this.route_distance = route_distance;
	}
	public String getRoute_distance_uom() {
		return route_distance_uom;
	}
	public void setRoute_distance_uom(String route_distance_uom) {
		this.route_distance_uom = route_distance_uom;
	}
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public String getShipping_type_descr() {
		return shipping_type_descr;
	}
	public void setShipping_type_descr(String shipping_type_descr) {
		this.shipping_type_descr = shipping_type_descr;
	}
	public String getVehicle_type_descr() {
		return vehicle_type_descr;
	}
	public void setVehicle_type_descr(String vehicle_type_descr) {
		this.vehicle_type_descr = vehicle_type_descr;
	}
	public String getDriver_name() {
		return driver_name;
	}
	public void setDriver_name(String driver_name) {
		this.driver_name = driver_name;
	}
	public String getLicence_no() {
		return licence_no;
	}
	public void setLicence_no(String licence_no) {
		this.licence_no = licence_no;
	}
	public Date getExpiry_date() {
		return expiry_date;
	}
	public void setExpiry_date(Date expiry_date) {
		this.expiry_date = expiry_date;
	}
	public String getLicence_issuing_state() {
		return licence_issuing_state;
	}
	public void setLicence_issuing_state(String licence_issuing_state) {
		this.licence_issuing_state = licence_issuing_state;
	}
	public String getGrn_applicable() {
		return grn_applicable;
	}
	public void setGrn_applicable(String grn_applicable) {
		this.grn_applicable = grn_applicable;
	}
	public String getAttendance_applicable() {
		return attendance_applicable;
	}
	public void setAttendance_applicable(String attendance_applicable) {
		this.attendance_applicable = attendance_applicable;
	}
	public int getTransport_order_no() {
		return transport_order_no;
	}
	public void setTransport_order_no(int transport_order_no) {
		this.transport_order_no = transport_order_no;
	}
	public Date getTransport_order_date() {
		return transport_order_date;
	}
	public void setTransport_order_date(Date transport_order_date) {
		this.transport_order_date = transport_order_date;
	}
	public String getReturn_order() {
		return return_order;
	}
	public void setReturn_order(String return_order) {
		this.return_order = return_order;
	}
	public int getOnward_reference() {
		return onward_reference;
	}
	public void setOnward_reference(int onward_reference) {
		this.onward_reference = onward_reference;
	}
	public String getBusiness_id() {
		return business_id;
	}
	public void setBusiness_id(String business_id) {
		this.business_id = business_id;
	}
	public String getSubusiness_id() {
		return subusiness_id;
	}
	public void setSubusiness_id(String subusiness_id) {
		this.subusiness_id = subusiness_id;
	}
	public String getProduct_category() {
		return product_category;
	}
	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}
	public String getGst_plant() {
		return gst_plant;
	}
	public void setGst_plant(String gst_plant) {
		this.gst_plant = gst_plant;
	}
	public String getCtd_indicator() {
		return ctd_indicator;
	}
	public void setCtd_indicator(String ctd_indicator) {
		this.ctd_indicator = ctd_indicator;
	}
	public String getConsignment_category() {
		return consignment_category;
	}
	public void setConsignment_category(String consignment_category) {
		this.consignment_category = consignment_category;
	}
	public String getMovt_dir() {
		return movt_dir;
	}
	public void setMovt_dir(String movt_dir) {
		this.movt_dir = movt_dir;
	}
	public float getCust_apprv_ftl_qty() {
		return cust_apprv_ftl_qty;
	}
	public void setCust_apprv_ftl_qty(float cust_apprv_ftl_qty) {
		this.cust_apprv_ftl_qty = cust_apprv_ftl_qty;
	}
	public String getCreatedbyid() {
		return createdbyid;
	}
	public void setCreatedbyid(String createdbyid) {
		this.createdbyid = createdbyid;
	}
	public Date getCreatedon() {
		return createdon;
	}
	public void setCreatedon(Date createdon) {
		this.createdon = createdon;
	}
	public String getCreatedbyname() {
		return createdbyname;
	}
	public void setCreatedbyname(String createdbyname) {
		this.createdbyname = createdbyname;
	}
	
}
