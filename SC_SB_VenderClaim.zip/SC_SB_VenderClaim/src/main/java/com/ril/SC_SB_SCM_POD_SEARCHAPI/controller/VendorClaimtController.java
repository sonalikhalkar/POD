package com.ril.SC_SB_SCM_POD_SEARCHAPI.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ril.SC_SB_SCM_POD_SEARCHAPI.exceptionhandler.CustomException;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.ShipementList;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.model.SupplyChainMgmtSearchList;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.service.ApproveChargesShipmentList;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.service.SearchList;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.util.ResponseFormat;
import com.ril.SC_SB_SCM_POD_SEARCHAPI.util.ValidateMethod;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@CrossOrigin
@Api(description = "Vendor Claimt Controller")
@Validated
public class VendorClaimtController 
{
	@Autowired
	ApproveChargesShipmentList approveChargesShipmentList;

	@Autowired
	SearchList searchList;

	/*
	 * @GetMapping("/shipementList")
	 * 
	 * @ApiOperation("pending CNs for Approve Charges") public
	 * ResponseEntity<ResponseFormat> shipementList(
	 * 
	 * @ApiParam(value = "Enter Vendor Code", defaultValue =
	 * "101681") @RequestParam(value = "vendor_code") String vendor_code,
	 * 
	 * @ApiParam(value = "Enter Start Date", defaultValue =
	 * "2019/10/01") @RequestParam(value = "start_date") Date start_date,
	 * 
	 * @ApiParam(value = "Enter End Date", defaultValue =
	 * "2019/10/01") @RequestParam(value = "end_date") Date end_date,
	 * 
	 * @ApiParam(value = "Enter Mode", defaultValue = "RD") @RequestParam(value =
	 * "mode") String mode,
	 * 
	 * @ApiParam(value = "Enter service category", defaultValue =
	 * "FTL") @RequestParam(value = "service_cat") String service_cat,
	 * 
	 * @ApiParam(value = "Enter customer id", defaultValue =
	 * "RILH01") @RequestParam(value = "cust_id") String cust_id,
	 * 
	 * @ApiParam(value = "Enter transaction status", defaultValue =
	 * "04") @RequestParam(value = "tdn_status") String tdn_status )
	 * 
	 * { ResponseFormat resShipementList = new ResponseFormat();
	 * 
	 * List<ShipementList> dashboardDtlJson =
	 * approveChargesShipmentList.getShipmentList(vendor_code, start_date, end_date,
	 * mode, service_cat, cust_id, tdn_status); if(!dashboardDtlJson.isEmpty()) {
	 * resShipementList.setSuccess("True"); resShipementList.setError("False");
	 * resShipementList.setData(dashboardDtlJson);
	 * resShipementList.setMessage("Record fetched successfully."); return new
	 * ResponseEntity<>(resShipementList,HttpStatus.OK); } else {
	 * resShipementList.setSuccess("True"); resShipementList.setError("False");
	 * resShipementList.setMessage("No Record Found!!!"); return new
	 * ResponseEntity<>(resShipementList,HttpStatus.OK); }
	 * 
	 * }
	 */

	@GetMapping("/searchList")
	@ApiOperation("Supply Chain Search List")
	public ResponseEntity<ResponseFormat> supplyChainsearchList(
			@ApiParam(value = "Enter Transport order number", defaultValue = "47") @RequestParam(value = "transport_order_no") int transport_order_no,
			@ApiParam(value = "Enter Customer Name", defaultValue = "Reliance Petrochemicals") @RequestParam(value = "cust_name") String customer_name,
			@ApiParam(value = "Enter Vendor Name", defaultValue = "Surat Road King") @RequestParam(value = "vendor_name") String name,
			@ApiParam(value = "Enter Vehicle Number", defaultValue = "AP07W1982") @RequestParam(value = "vehicle_number") String vehicle_number,
			@ApiParam(value = "Enter Source Location", defaultValue = "HAZIRA") @RequestParam(value = "source_location") String source_location,
			@ApiParam(value = "Enter Destination Location", defaultValue = "D-PUNE") @RequestParam(value = "destination_location") String destination_location,
			@ApiParam(value = "Enter Shipement Date ", defaultValue = "2019/07/22") @RequestParam(value = "shipment_date") Date shipment_date

			)
	{


		ResponseFormat resShipementList = new ResponseFormat();		


		List<SupplyChainMgmtSearchList> supplyChainMgmtSearchListJson = searchList.getSearchList(transport_order_no, customer_name, name, vehicle_number, source_location, destination_location, shipment_date);
				if(!supplyChainMgmtSearchListJson.isEmpty())
				{
					resShipementList.setSuccess("True");
					resShipementList.setError("False");
					resShipementList.setData(supplyChainMgmtSearchListJson);
					resShipementList.setMessage("Record fetched successfully.");
					return new ResponseEntity<>(resShipementList,HttpStatus.OK);
				}
				else 
				{
					resShipementList.setSuccess("True");
					resShipementList.setError("False");
					resShipementList.setMessage("No Record Found!!!");
					return new ResponseEntity<>(resShipementList,HttpStatus.OK);
				}


	}
}
