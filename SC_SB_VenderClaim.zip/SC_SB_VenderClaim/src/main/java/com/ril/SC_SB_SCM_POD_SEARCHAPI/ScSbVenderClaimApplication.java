package com.ril.SC_SB_SCM_POD_SEARCHAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScSbVenderClaimApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScSbVenderClaimApplication.class, args);
	}

}
