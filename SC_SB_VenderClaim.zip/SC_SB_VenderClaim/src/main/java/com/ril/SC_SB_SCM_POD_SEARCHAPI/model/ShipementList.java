package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.util.Date;

public class ShipementList 
{
	private String refdocno;
	private int CN_count;
	private String veh_no;
	private String source_location;
	private String destination_location;
	private Date shipment_start_date;
	private String vendor_code;
	private String cust_id;
	private String shipmenttype;
	private String tpp;
	private Date start_date;
	private Date end_date;
	
	public String getRefdocno() {
		return refdocno;
	}
	public void setRefdocno(String refdocno) {
		this.refdocno = refdocno;
	}
	
	public int getCN_count() {
		return CN_count;
	}
	public void setCN_count(int cN_count) {
		CN_count = cN_count;
	}
	public String getVeh_no() {
		return veh_no;
	}
	public void setVeh_no(String veh_no) {
		this.veh_no = veh_no;
	}
	public String getSource_location() {
		return source_location;
	}
	public void setSource_location(String source_location) {
		this.source_location = source_location;
	}
	public String getDestination_location() {
		return destination_location;
	}
	public void setDestination_location(String destination_location) {
		this.destination_location = destination_location;
	}
	
	public Date getShipment_start_date() {
		return shipment_start_date;
	}
	public void setShipment_start_date(Date shipment_start_date) {
		this.shipment_start_date = shipment_start_date;
	}
	public String getVendor_code() {
		return vendor_code;
	}
	public void setVendor_code(String vendor_code) {
		this.vendor_code = vendor_code;
	}
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getShipmenttype() {
		return shipmenttype;
	}
	public void setShipmenttype(String shipmenttype) {
		this.shipmenttype = shipmenttype;
	}
	public String getTpp() {
		return tpp;
	}
	public void setTpp(String tpp) {
		this.tpp = tpp;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	
	

}
