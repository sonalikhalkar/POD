package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="SCME_MD_CUSTOMER")
public class ScmeMdCustomer 
{
	@EmbeddedId
	TransportDocScmeMdCustomer transportDocScmeMdCustomer;
	
	private String CUSTOMER_NAME;
	private int LOCATION_ID;
	private String ADDRESS_KEY; 
	private String CREATED_BY;
	private Date CREATED_DATE;
	private String LAST_UPDATED_BY;
	private Date LAST_UPDATE_DATE;
	
	
	public TransportDocScmeMdCustomer getTransportDocScmeMdCustomer() {
		return transportDocScmeMdCustomer;
	}
	public void setTransportDocScmeMdCustomer(TransportDocScmeMdCustomer transportDocScmeMdCustomer) {
		this.transportDocScmeMdCustomer = transportDocScmeMdCustomer;
	}
	public String getCUSTOMER_NAME() {
		return CUSTOMER_NAME;
	}
	public void setCUSTOMER_NAME(String cUSTOMER_NAME) {
		CUSTOMER_NAME = cUSTOMER_NAME;
	}
	public int getLOCATION_ID() {
		return LOCATION_ID;
	}
	public void setLOCATION_ID(int lOCATION_ID) {
		LOCATION_ID = lOCATION_ID;
	}
	public String getADDRESS_KEY() {
		return ADDRESS_KEY;
	}
	public void setADDRESS_KEY(String aDDRESS_KEY) {
		ADDRESS_KEY = aDDRESS_KEY;
	}
	public String getCREATED_BY() {
		return CREATED_BY;
	}
	public void setCREATED_BY(String cREATED_BY) {
		CREATED_BY = cREATED_BY;
	}
	public Date getCREATED_DATE() {
		return CREATED_DATE;
	}
	public void setCREATED_DATE(Date cREATED_DATE) {
		CREATED_DATE = cREATED_DATE;
	}
	public String getLAST_UPDATED_BY() {
		return LAST_UPDATED_BY;
	}
	public void setLAST_UPDATED_BY(String lAST_UPDATED_BY) {
		LAST_UPDATED_BY = lAST_UPDATED_BY;
	}
	public Date getLAST_UPDATE_DATE() {
		return LAST_UPDATE_DATE;
	}
	public void setLAST_UPDATE_DATE(Date lAST_UPDATE_DATE) {
		LAST_UPDATE_DATE = lAST_UPDATE_DATE;
	}
	
	
}
