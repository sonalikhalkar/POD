package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.util.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="SCME_TR_TDN_INV_HEADER")
public class ScmeTrTdnInvHeader
{
	@EmbeddedId
	TransportDocHeaderIdentity transportDocHeaderIdentity;
	
	private String source;
	private String shippingtype;
	private String consignment_category;
	private String movt_dir;
	private Date docdate;
	private Date doctime;
	private String rej_rsn_code;
	private String createdby;
	private String refdocno;
	private String tdn_status;
	private String vendor_code;
	private String trbillno;
	private int trbillfyear;
	private Date trbilldate;
	private String shipmenttype;
	private String shippingtype_descrp;
	private String tpp;
	private String cust_id;
	private String companycode;
	private String route;
	private float liabilityamt;
	private String block_reason;
	private String block_reasondescrp;
	private Date tdn_startdate;
	private Date tdn_starttime;
	private Date tdn_enddate;
	private Date tdn_endtime;
	private String veh_no;
	private String veh_type;
	private String veh_type_descrp;
	private float veh_cap;
	private String veh_capUom;
	private float freightrate;
	private float freightvalue;
	private String currency;
	private int shmt_docno;
	private boolean ctdflag;
	private boolean ftlflag;
	private String trnshmt_flag;
	private String trnshmt_truck;
	private String trnshmt_reason;
	private boolean app_trnshmt_flag;
	private String waiverTransit_delay;
	private int delaydays;
	private String delay_reason;
	private int appdelaydays;
	private String det_indic_org;
	private int det_day_org;
	private String det_reason_org;
	private float det_amt_org;
	private String det_indic_dest;
	private int det_day_dest;
	private String det_reason_dest;
	private float det_amt_dest;
	private int det_org_apprDays;
	private String det_org_apprAmt;
	private String det_org_apprInd;
	private int det_dest_apprDays;
	private float det_dest_apprAmt;
	private String det_dest_apprInd;
	private boolean diversion_flag;
	private boolean roundtripflag;
	private String createdbyid;
	private Date createdon;
	private String createdbyname;
	private String changebyid;
	private String changename;
	private Date changeon;
	
	
	
	public TransportDocHeaderIdentity getTransportDocHeaderIdentity() {
		return transportDocHeaderIdentity;
	}
	public void setTransportDocHeaderIdentity(TransportDocHeaderIdentity transportDocHeaderIdentity) {
		this.transportDocHeaderIdentity = transportDocHeaderIdentity;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getShippingtype() {
		return shippingtype;
	}
	public void setShippingtype(String shippingtype) {
		this.shippingtype = shippingtype;
	}
	public String getConsignment_category() {
		return consignment_category;
	}
	public void setConsignment_category(String consignment_category) {
		this.consignment_category = consignment_category;
	}
	public String getMovt_dir() {
		return movt_dir;
	}
	public void setMovt_dir(String movt_dir) {
		this.movt_dir = movt_dir;
	}
	public Date getDocdate() {
		return docdate;
	}
	public void setDocdate(Date docdate) {
		this.docdate = docdate;
	}
	public Date getDoctime() {
		return doctime;
	}
	public void setDoctime(Date doctime) {
		this.doctime = doctime;
	}
	public String getRej_rsn_code() {
		return rej_rsn_code;
	}
	public void setRej_rsn_code(String rej_rsn_code) {
		this.rej_rsn_code = rej_rsn_code;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public String getRefdocno() {
		return refdocno;
	}
	public void setRefdocno(String refdocno) {
		this.refdocno = refdocno;
	}
	public String getTdn_status() {
		return tdn_status;
	}
	public void setTdn_status(String tdn_status) {
		this.tdn_status = tdn_status;
	}
	public String getVendor_code() {
		return vendor_code;
	}
	public void setVendor_code(String vendor_code) {
		this.vendor_code = vendor_code;
	}
	public String getTrbillno() {
		return trbillno;
	}
	public void setTrbillno(String trbillno) {
		this.trbillno = trbillno;
	}
	public int getTrbillfyear() {
		return trbillfyear;
	}
	public void setTrbillfyear(int trbillfyear) {
		this.trbillfyear = trbillfyear;
	}
	public Date getTrbilldate() {
		return trbilldate;
	}
	public void setTrbilldate(Date trbilldate) {
		this.trbilldate = trbilldate;
	}
	public String getShipmenttype() {
		return shipmenttype;
	}
	public void setShipmenttype(String shipmenttype) {
		this.shipmenttype = shipmenttype;
	}
	public String getShippingtype_descrp() {
		return shippingtype_descrp;
	}
	public void setShippingtype_descrp(String shippingtype_descrp) {
		this.shippingtype_descrp = shippingtype_descrp;
	}
	public String getTpp() {
		return tpp;
	}
	public void setTpp(String tpp) {
		this.tpp = tpp;
	}
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public String getRoute() {
		return route;
	}
	public void setRoute(String route) {
		this.route = route;
	}
	public float getLiabilityamt() {
		return liabilityamt;
	}
	public void setLiabilityamt(float liabilityamt) {
		this.liabilityamt = liabilityamt;
	}
	public String getBlock_reason() {
		return block_reason;
	}
	public void setBlock_reason(String block_reason) {
		this.block_reason = block_reason;
	}
	public String getBlock_reasondescrp() {
		return block_reasondescrp;
	}
	public void setBlock_reasondescrp(String block_reasondescrp) {
		this.block_reasondescrp = block_reasondescrp;
	}
	public Date getTdn_startdate() {
		return tdn_startdate;
	}
	public void setTdn_startdate(Date tdn_startdate) {
		this.tdn_startdate = tdn_startdate;
	}
	public Date getTdn_starttime() {
		return tdn_starttime;
	}
	public void setTdn_starttime(Date tdn_starttime) {
		this.tdn_starttime = tdn_starttime;
	}
	public Date getTdn_enddate() {
		return tdn_enddate;
	}
	public void setTdn_enddate(Date tdn_enddate) {
		this.tdn_enddate = tdn_enddate;
	}
	public Date getTdn_endtime() {
		return tdn_endtime;
	}
	public void setTdn_endtime(Date tdn_endtime) {
		this.tdn_endtime = tdn_endtime;
	}
	public String getVeh_no() {
		return veh_no;
	}
	public void setVeh_no(String veh_no) {
		this.veh_no = veh_no;
	}
	public String getVeh_type() {
		return veh_type;
	}
	public void setVeh_type(String veh_type) {
		this.veh_type = veh_type;
	}
	public String getVeh_type_descrp() {
		return veh_type_descrp;
	}
	public void setVeh_type_descrp(String veh_type_descrp) {
		this.veh_type_descrp = veh_type_descrp;
	}
	public float getVeh_cap() {
		return veh_cap;
	}
	public void setVeh_cap(float veh_cap) {
		this.veh_cap = veh_cap;
	}
	public String getVeh_capUom() {
		return veh_capUom;
	}
	public void setVeh_capUom(String veh_capUom) {
		this.veh_capUom = veh_capUom;
	}
	public float getFreightrate() {
		return freightrate;
	}
	public void setFreightrate(float freightrate) {
		this.freightrate = freightrate;
	}
	public float getFreightvalue() {
		return freightvalue;
	}
	public void setFreightvalue(float freightvalue) {
		this.freightvalue = freightvalue;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public int getShmt_docno() {
		return shmt_docno;
	}
	public void setShmt_docno(int shmt_docno) {
		this.shmt_docno = shmt_docno;
	}
	public boolean isCtdflag() {
		return ctdflag;
	}
	public void setCtdflag(boolean ctdflag) {
		this.ctdflag = ctdflag;
	}
	public boolean isFtlflag() {
		return ftlflag;
	}
	public void setFtlflag(boolean ftlflag) {
		this.ftlflag = ftlflag;
	}
	public String getTrnshmt_flag() {
		return trnshmt_flag;
	}
	public void setTrnshmt_flag(String trnshmt_flag) {
		this.trnshmt_flag = trnshmt_flag;
	}
	public String getTrnshmt_truck() {
		return trnshmt_truck;
	}
	public void setTrnshmt_truck(String trnshmt_truck) {
		this.trnshmt_truck = trnshmt_truck;
	}
	public String getTrnshmt_reason() {
		return trnshmt_reason;
	}
	public void setTrnshmt_reason(String trnshmt_reason) {
		this.trnshmt_reason = trnshmt_reason;
	}
	public boolean isApp_trnshmt_flag() {
		return app_trnshmt_flag;
	}
	public void setApp_trnshmt_flag(boolean app_trnshmt_flag) {
		this.app_trnshmt_flag = app_trnshmt_flag;
	}
	public String getWaiverTransit_delay() {
		return waiverTransit_delay;
	}
	public void setWaiverTransit_delay(String waiverTransit_delay) {
		this.waiverTransit_delay = waiverTransit_delay;
	}
	public int getDelaydays() {
		return delaydays;
	}
	public void setDelaydays(int delaydays) {
		this.delaydays = delaydays;
	}
	public String getDelay_reason() {
		return delay_reason;
	}
	public void setDelay_reason(String delay_reason) {
		this.delay_reason = delay_reason;
	}
	public int getAppdelaydays() {
		return appdelaydays;
	}
	public void setAppdelaydays(int appdelaydays) {
		this.appdelaydays = appdelaydays;
	}
	public String getDet_indic_org() {
		return det_indic_org;
	}
	public void setDet_indic_org(String det_indic_org) {
		this.det_indic_org = det_indic_org;
	}
	public int getDet_day_org() {
		return det_day_org;
	}
	public void setDet_day_org(int det_day_org) {
		this.det_day_org = det_day_org;
	}
	public String getDet_reason_org() {
		return det_reason_org;
	}
	public void setDet_reason_org(String det_reason_org) {
		this.det_reason_org = det_reason_org;
	}
	public float getDet_amt_org() {
		return det_amt_org;
	}
	public void setDet_amt_org(float det_amt_org) {
		this.det_amt_org = det_amt_org;
	}
	public String getDet_indic_dest() {
		return det_indic_dest;
	}
	public void setDet_indic_dest(String det_indic_dest) {
		this.det_indic_dest = det_indic_dest;
	}
	public int getDet_day_dest() {
		return det_day_dest;
	}
	public void setDet_day_dest(int det_day_dest) {
		this.det_day_dest = det_day_dest;
	}
	public String getDet_reason_dest() {
		return det_reason_dest;
	}
	public void setDet_reason_dest(String det_reason_dest) {
		this.det_reason_dest = det_reason_dest;
	}
	public float getDet_amt_dest() {
		return det_amt_dest;
	}
	public void setDet_amt_dest(float det_amt_dest) {
		this.det_amt_dest = det_amt_dest;
	}
	public int getDet_org_apprDays() {
		return det_org_apprDays;
	}
	public void setDet_org_apprDays(int det_org_apprDays) {
		this.det_org_apprDays = det_org_apprDays;
	}
	public String getDet_org_apprAmt() {
		return det_org_apprAmt;
	}
	public void setDet_org_apprAmt(String det_org_apprAmt) {
		this.det_org_apprAmt = det_org_apprAmt;
	}
	public String getDet_org_apprInd() {
		return det_org_apprInd;
	}
	public void setDet_org_apprInd(String det_org_apprInd) {
		this.det_org_apprInd = det_org_apprInd;
	}
	public int getDet_dest_apprDays() {
		return det_dest_apprDays;
	}
	public void setDet_dest_apprDays(int det_dest_apprDays) {
		this.det_dest_apprDays = det_dest_apprDays;
	}
	public float getDet_dest_apprAmt() {
		return det_dest_apprAmt;
	}
	public void setDet_dest_apprAmt(float det_dest_apprAmt) {
		this.det_dest_apprAmt = det_dest_apprAmt;
	}
	public String getDet_dest_apprInd() {
		return det_dest_apprInd;
	}
	public void setDet_dest_apprInd(String det_dest_apprInd) {
		this.det_dest_apprInd = det_dest_apprInd;
	}
	public boolean isDiversion_flag() {
		return diversion_flag;
	}
	public void setDiversion_flag(boolean diversion_flag) {
		this.diversion_flag = diversion_flag;
	}
	public boolean isRoundtripflag() {
		return roundtripflag;
	}
	public void setRoundtripflag(boolean roundtripflag) {
		this.roundtripflag = roundtripflag;
	}
	public String getCreatedbyid() {
		return createdbyid;
	}
	public void setCreatedbyid(String createdbyid) {
		this.createdbyid = createdbyid;
	}
	public Date getCreatedon() {
		return createdon;
	}
	public void setCreatedon(Date createdon) {
		this.createdon = createdon;
	}
	public String getCreatedbyname() {
		return createdbyname;
	}
	public void setCreatedbyname(String createdbyname) {
		this.createdbyname = createdbyname;
	}
	public String getChangebyid() {
		return changebyid;
	}
	public void setChangebyid(String changebyid) {
		this.changebyid = changebyid;
	}
	public String getChangename() {
		return changename;
	}
	public void setChangename(String changename) {
		this.changename = changename;
	}
	public Date getChangeon() {
		return changeon;
	}
	public void setChangeon(Date changeon) {
		this.changeon = changeon;
	}
	
	
}
