package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.util.Date;

public class SupplyChainMgmtSearchList 
{
	private String customer_name;
	private String customer_id;
	private String source_location;
	private String destination_location;
	private Date shipment_date;
	private String vendor_name;
	private String vendor_code;
	private  String vehicle_number;
	private String vehicle_type;
	private double vehicle_capacity;
	private String route_distance;
	
	
	
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String string) {
		this.customer_id = string;
	}
	public String getRoute_distance() {
		return route_distance;
	}
	public void setRoute_distance(String route_distance) {
		this.route_distance = route_distance;
	}
	public String getSource_location() {
		return source_location;
	}
	public void setSource_location(String source_location) {
		this.source_location = source_location;
	}
	public String getDestination_location() {
		return destination_location;
	}
	public void setDestination_location(String destination_location) {
		this.destination_location = destination_location;
	}
	public Date getShipment_date() {
		return shipment_date;
	}
	public void setShipment_date(Date shipment_date) {
		this.shipment_date = shipment_date;
	}
	public String getVendor_name() {
		return vendor_name;
	}
	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}
	public String getVendor_code() {
		return vendor_code;
	}
	public void setVendor_code(String vendor_code) {
		this.vendor_code = vendor_code;
	}
	public String getVehicle_number() {
		return vehicle_number;
	}
	public void setVehicle_number(String vehicle_number) {
		this.vehicle_number = vehicle_number;
	}
	public String getVehicle_type() {
		return vehicle_type;
	}
	public void setVehicle_type(String vehicle_type) {
		this.vehicle_type = vehicle_type;
	}
	public double getVehicle_capacity() {
		return vehicle_capacity;
	}
	public void setVehicle_capacity(double vehicle_capacity) {
		this.vehicle_capacity = vehicle_capacity;
	}
	
	
	
}
