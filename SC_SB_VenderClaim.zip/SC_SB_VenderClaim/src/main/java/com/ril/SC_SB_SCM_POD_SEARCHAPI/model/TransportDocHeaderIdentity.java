package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class TransportDocHeaderIdentity implements Serializable 
{
	private static final long serialVersionUID = 1L;
	
	@NotNull
	private int tdn;
	
	@NotNull
	private int fyear;
		
	public int getTdn() {
		return tdn;
	}

	public void setTdn(int tdn) {
		this.tdn = tdn;
	}

	public int getFyear() {
		return fyear;
	}

	public void setFyear(int fyear) {
		this.fyear = fyear;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + fyear;
		result = prime * result + tdn;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransportDocHeaderIdentity other = (TransportDocHeaderIdentity) obj;
		if (fyear != other.fyear)
			return false;
		if (tdn != other.tdn)
			return false;
		return true;
	}
}
