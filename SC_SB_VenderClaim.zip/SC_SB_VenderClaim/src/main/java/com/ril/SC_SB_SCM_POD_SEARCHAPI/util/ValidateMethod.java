package com.ril.SC_SB_SCM_POD_SEARCHAPI.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

public interface ValidateMethod
{
	
	public static boolean isValidFormat(String value) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date date = sdf.parse(value);
            if (value.equals(sdf.format(date))) {
                return true;
            }
        } catch (ParseException ex) {
            return false;
        }
        return false;
    }
	
	public static boolean isValidBillNo(String value) 
	{
		Pattern pattern = Pattern.compile(".*[^0-9].*");
		
		if(value==null || value.length()==0)
		{
			return false;
		}
		else {
			return !pattern.matcher(value).matches();
		}	    
    }

}
