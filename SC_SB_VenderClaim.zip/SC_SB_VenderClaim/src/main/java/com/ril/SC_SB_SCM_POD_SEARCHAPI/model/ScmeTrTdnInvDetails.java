package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.util.Date;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="SCME_TR_TDN_INV_DETAILS")
public class ScmeTrTdnInvDetails
{
	@EmbeddedId
	TransportDocItemIdentity transDocItemIdentity;
	
	private String tdn_status;
	private Date cndate;
	private float cnqty;
	private String cnuom;
	private int dcpi_no;
	private float dcpi_qty;
	private String dcpi_uom;
	private Date dcpi_date;
	private String dcpi_netval;
	private String dcpi_curr;
	private String mat_frgrp;
	private int delivery_no;
	private float delivery_qty;
	private int delivery_grosswt;
	private int delivery_netwt;
	private String delivered_uom;
	private Date delivered_date;
	private String prec_doctype;
	private String salesuom;
	private String route;
	private String sourcetzone;
	private String desttzone;
	private int grn_no;
	private Date grn_date;
	private float grn_qty;
	private String grn_uom;
	private float grn_cntqty;
	private float grn_sweepqty;
	private Date v_poddate;
	private float v_podqty;
	private String v_poduom;
	private float v_sweepqty;
	private float v_cntqty;
	private Date e_poddate;
	private float e_podqty;
	private String e_poduom;
	private float e_sweepqty;
	private float e_cntqty;
	private Date m_poddate;
	private float m_podqty;
	private String m_poduom;
	private float m_sweepqty;
	private float m_cntqty;
	private String podtype;
	private Date poddate;
	private float podqty;
	private String poduom;
	private float podcntqty;
	private float podsweepqty;
	private String createdbyid;
	private Date createdon;
	private String createdbyname;
	private String changebyid;
	private String changename;
	private Date changeon;
	
	public TransportDocItemIdentity getTransDocItemIdentity() {
		return transDocItemIdentity;
	}
	public void setTransDocItemIdentity(TransportDocItemIdentity transDocItemIdentity) {
		this.transDocItemIdentity = transDocItemIdentity;
	}
	public String getTdn_status() {
		return tdn_status;
	}
	public void setTdn_status(String tdn_status) {
		this.tdn_status = tdn_status;
	}
	public Date getCndate() {
		return cndate;
	}
	public void setCndate(Date cndate) {
		this.cndate = cndate;
	}
	public float getCnqty() {
		return cnqty;
	}
	public void setCnqty(float cnqty) {
		this.cnqty = cnqty;
	}
	public String getCnuom() {
		return cnuom;
	}
	public void setCnuom(String cnuom) {
		this.cnuom = cnuom;
	}
	public int getDcpi_no() {
		return dcpi_no;
	}
	public void setDcpi_no(int dcpi_no) {
		this.dcpi_no = dcpi_no;
	}
	public float getDcpi_qty() {
		return dcpi_qty;
	}
	public void setDcpi_qty(float dcpi_qty) {
		this.dcpi_qty = dcpi_qty;
	}
	public String getDcpi_uom() {
		return dcpi_uom;
	}
	public void setDcpi_uom(String dcpi_uom) {
		this.dcpi_uom = dcpi_uom;
	}
	public Date getDcpi_date() {
		return dcpi_date;
	}
	public void setDcpi_date(Date dcpi_date) {
		this.dcpi_date = dcpi_date;
	}
	public String getDcpi_netval() {
		return dcpi_netval;
	}
	public void setDcpi_netval(String dcpi_netval) {
		this.dcpi_netval = dcpi_netval;
	}
	public String getDcpi_curr() {
		return dcpi_curr;
	}
	public void setDcpi_curr(String dcpi_curr) {
		this.dcpi_curr = dcpi_curr;
	}
	public String getMat_frgrp() {
		return mat_frgrp;
	}
	public void setMat_frgrp(String mat_frgrp) {
		this.mat_frgrp = mat_frgrp;
	}
	public int getDelivery_no() {
		return delivery_no;
	}
	public void setDelivery_no(int delivery_no) {
		this.delivery_no = delivery_no;
	}
	public float getDelivery_qty() {
		return delivery_qty;
	}
	public void setDelivery_qty(float delivery_qty) {
		this.delivery_qty = delivery_qty;
	}
	public int getDelivery_grosswt() {
		return delivery_grosswt;
	}
	public void setDelivery_grosswt(int delivery_grosswt) {
		this.delivery_grosswt = delivery_grosswt;
	}
	public int getDelivery_netwt() {
		return delivery_netwt;
	}
	public void setDelivery_netwt(int delivery_netwt) {
		this.delivery_netwt = delivery_netwt;
	}
	public String getDelivered_uom() {
		return delivered_uom;
	}
	public void setDelivered_uom(String delivered_uom) {
		this.delivered_uom = delivered_uom;
	}
	public Date getDelivered_date() {
		return delivered_date;
	}
	public void setDelivered_date(Date delivered_date) {
		this.delivered_date = delivered_date;
	}
	public String getPrec_doctype() {
		return prec_doctype;
	}
	public void setPrec_doctype(String prec_doctype) {
		this.prec_doctype = prec_doctype;
	}
	public String getSalesuom() {
		return salesuom;
	}
	public void setSalesuom(String salesuom) {
		this.salesuom = salesuom;
	}
	public String getRoute() {
		return route;
	}
	public void setRoute(String route) {
		this.route = route;
	}
	public String getSourcetzone() {
		return sourcetzone;
	}
	public void setSourcetzone(String sourcetzone) {
		this.sourcetzone = sourcetzone;
	}
	public String getDesttzone() {
		return desttzone;
	}
	public void setDesttzone(String desttzone) {
		this.desttzone = desttzone;
	}
	public int getGrn_no() {
		return grn_no;
	}
	public void setGrn_no(int grn_no) {
		this.grn_no = grn_no;
	}
	public Date getGrn_date() {
		return grn_date;
	}
	public void setGrn_date(Date grn_date) {
		this.grn_date = grn_date;
	}
	public float getGrn_qty() {
		return grn_qty;
	}
	public void setGrn_qty(float grn_qty) {
		this.grn_qty = grn_qty;
	}
	public String getGrn_uom() {
		return grn_uom;
	}
	public void setGrn_uom(String grn_uom) {
		this.grn_uom = grn_uom;
	}
	public float getGrn_cntqty() {
		return grn_cntqty;
	}
	public void setGrn_cntqty(float grn_cntqty) {
		this.grn_cntqty = grn_cntqty;
	}
	public float getGrn_sweepqty() {
		return grn_sweepqty;
	}
	public void setGrn_sweepqty(float grn_sweepqty) {
		this.grn_sweepqty = grn_sweepqty;
	}
	public Date getV_poddate() {
		return v_poddate;
	}
	public void setV_poddate(Date v_poddate) {
		this.v_poddate = v_poddate;
	}
	public float getV_podqty() {
		return v_podqty;
	}
	public void setV_podqty(float v_podqty) {
		this.v_podqty = v_podqty;
	}
	public String getV_poduom() {
		return v_poduom;
	}
	public void setV_poduom(String v_poduom) {
		this.v_poduom = v_poduom;
	}
	public float getV_sweepqty() {
		return v_sweepqty;
	}
	public void setV_sweepqty(float v_sweepqty) {
		this.v_sweepqty = v_sweepqty;
	}
	public float getV_cntqty() {
		return v_cntqty;
	}
	public void setV_cntqty(float v_cntqty) {
		this.v_cntqty = v_cntqty;
	}
	public Date getE_poddate() {
		return e_poddate;
	}
	public void setE_poddate(Date e_poddate) {
		this.e_poddate = e_poddate;
	}
	public float getE_podqty() {
		return e_podqty;
	}
	public void setE_podqty(float e_podqty) {
		this.e_podqty = e_podqty;
	}
	public String getE_poduom() {
		return e_poduom;
	}
	public void setE_poduom(String e_poduom) {
		this.e_poduom = e_poduom;
	}
	public float getE_sweepqty() {
		return e_sweepqty;
	}
	public void setE_sweepqty(float e_sweepqty) {
		this.e_sweepqty = e_sweepqty;
	}
	public float getE_cntqty() {
		return e_cntqty;
	}
	public void setE_cntqty(float e_cntqty) {
		this.e_cntqty = e_cntqty;
	}
	public Date getM_poddate() {
		return m_poddate;
	}
	public void setM_poddate(Date m_poddate) {
		this.m_poddate = m_poddate;
	}
	public float getM_podqty() {
		return m_podqty;
	}
	public void setM_podqty(float m_podqty) {
		this.m_podqty = m_podqty;
	}
	public String getM_poduom() {
		return m_poduom;
	}
	public void setM_poduom(String m_poduom) {
		this.m_poduom = m_poduom;
	}
	public float getM_sweepqty() {
		return m_sweepqty;
	}
	public void setM_sweepqty(float m_sweepqty) {
		this.m_sweepqty = m_sweepqty;
	}
	public float getM_cntqty() {
		return m_cntqty;
	}
	public void setM_cntqty(float m_cntqty) {
		this.m_cntqty = m_cntqty;
	}
	public String getPodtype() {
		return podtype;
	}
	public void setPodtype(String podtype) {
		this.podtype = podtype;
	}
	public Date getPoddate() {
		return poddate;
	}
	public void setPoddate(Date poddate) {
		this.poddate = poddate;
	}
	public float getPodqty() {
		return podqty;
	}
	public void setPodqty(float podqty) {
		this.podqty = podqty;
	}
	public String getPoduom() {
		return poduom;
	}
	public void setPoduom(String poduom) {
		this.poduom = poduom;
	}
	public float getPodcntqty() {
		return podcntqty;
	}
	public void setPodcntqty(float podcntqty) {
		this.podcntqty = podcntqty;
	}
	public float getPodsweepqty() {
		return podsweepqty;
	}
	public void setPodsweepqty(float podsweepqty) {
		this.podsweepqty = podsweepqty;
	}
	public String getCreatedbyid() {
		return createdbyid;
	}
	public void setCreatedbyid(String createdbyid) {
		this.createdbyid = createdbyid;
	}
	public Date getCreatedon() {
		return createdon;
	}
	public void setCreatedon(Date createdon) {
		this.createdon = createdon;
	}
	public String getCreatedbyname() {
		return createdbyname;
	}
	public void setCreatedbyname(String createdbyname) {
		this.createdbyname = createdbyname;
	}
	public String getChangebyid() {
		return changebyid;
	}
	public void setChangebyid(String changebyid) {
		this.changebyid = changebyid;
	}
	public String getChangename() {
		return changename;
	}
	public void setChangename(String changename) {
		this.changename = changename;
	}
	public Date getChangeon() {
		return changeon;
	}
	public void setChangeon(Date changeon) {
		this.changeon = changeon;
	}
	
	
}
