package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class TransportDocItemIdentity implements Serializable 
{
	private static final long serialVersionUID = 1L;
	
	@NotNull
	private int tdn;
	
	@NotNull
	private int fyear;
	
	@NotNull
	@Column(name="cn_no")
	private String cnno;
	
	@NotNull
	@Column(name="cn_itemno")
	private int itemno;
	
	@NotNull
	@Column(name="ref_itemno")
	private int refno;
	
	public int getTdn() {
		return tdn;
	}

	public void setTdn(int tdn) {
		this.tdn = tdn;
	}

	public int getFyear() {
		return fyear;
	}

	public void setFyear(int fyear) {
		this.fyear = fyear;
	}

	public String getCnno() {
		return cnno;
	}

	public void setCnno(String cnno) {
		this.cnno = cnno;
	}

	public int getItemno() {
		return itemno;
	}

	public void setItemno(int itemno) {
		this.itemno = itemno;
	}

	public int getRefno() {
		return refno;
	}

	public void setRefno(int refno) {
		this.refno = refno;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + fyear;
		result = prime * result + itemno;
		result = prime * result + refno;
		result = prime * result + tdn;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransportDocItemIdentity other = (TransportDocItemIdentity) obj;
		if (fyear != other.fyear)
			return false;
		if (itemno != other.itemno)
			return false;
		if (refno != other.refno)
			return false;
		if (tdn != other.tdn)
			return false;
		return true;
	}
}
