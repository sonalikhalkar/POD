package com.ril.SC_SB_SCM_POD_SEARCHAPI.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class TransportDocTrToHeaderData implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	@NotNull
	private String scm_customer_id;
	
	@NotNull
	private String shipment_no;
	
	@NotNull
	private int fiscal_year;

	public String getScm_customer_id() {
		return scm_customer_id;
	}

	public void setScm_customer_id(String scm_customer_id) {
		this.scm_customer_id = scm_customer_id;
	}

	public String getShipment_no() {
		return shipment_no;
	}

	public void setShipment_no(String shipment_no) {
		this.shipment_no = shipment_no;
	}

	public int getFiscal_year() {
		return fiscal_year;
	}

	public void setFiscal_year(int fiscal_year) {
		this.fiscal_year = fiscal_year;
	}
		
}
