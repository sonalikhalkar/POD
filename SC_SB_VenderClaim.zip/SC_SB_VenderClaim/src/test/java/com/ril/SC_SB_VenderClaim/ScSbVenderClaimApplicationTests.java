package com.ril.SC_SB_VenderClaim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScSbVenderClaimApplicationTests {

	@Test
	void contextLoads() {
	}

}
